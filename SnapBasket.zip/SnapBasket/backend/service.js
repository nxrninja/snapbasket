import './src/Worker/Welcome.worker.js'

